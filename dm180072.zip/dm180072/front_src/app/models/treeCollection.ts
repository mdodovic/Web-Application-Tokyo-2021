export class TreeCollection {
    index: number;
    player1: string;
    nationality1: string;
    player2: string;
    nationality2: string;
    score: string;
}