export class Timetable {
    sportName: string;
    disciplineName: string;
    gender: string;
    type: string;
    location: string;
    datetime: string;
}