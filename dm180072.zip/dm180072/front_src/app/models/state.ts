export class State {
    countryName: string;
    flag: string;
    bronseMedals: number;
    silverMedals: number;
    goldMedals: number;
}
