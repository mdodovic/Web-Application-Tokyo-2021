export class Discipline {
    disciplineName: string;
    single: boolean;
    minPlayers: number;
    maxPlayers: number;
    accepted: boolean;
}