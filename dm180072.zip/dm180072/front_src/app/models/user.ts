export class User {
    username: string;
    password: string;
    firstname: string;
    lastname: string;
    nationality: string;
    email: string;
    type: string;
    accepted: number;
}