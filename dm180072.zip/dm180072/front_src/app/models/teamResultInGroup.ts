export class TeamResultInGroup {
    nationality: string;
    team: string;
    points: number;
    playedPoints: number;
}
