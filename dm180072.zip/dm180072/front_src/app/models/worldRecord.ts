export class WorldRecord {
    year: number;
    place: string
    discipline: string
    competitor: string
    nationality: string
    result: string
    gender: string
}
