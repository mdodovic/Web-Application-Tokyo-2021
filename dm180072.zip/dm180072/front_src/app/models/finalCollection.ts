export class FinalCollection {
    nationality: string;
    player: string;
    score: string;
}