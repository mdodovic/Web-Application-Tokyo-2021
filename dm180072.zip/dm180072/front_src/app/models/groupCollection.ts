import { TeamResultInGroup } from "./teamResultInGroup";

export class GroupCollection {
    groupNumber: number;
    resultInGroups: Array<TeamResultInGroup>;
}