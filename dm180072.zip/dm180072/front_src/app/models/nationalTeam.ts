export class NationalTeam {

    nationality: string;
    sportName: string;
    disciplineName: string;
    gender: string;
    single: boolean;
    players: Array<String>;

}