/*
import mongoose from "mongoose";

const Schema = mongoose.Schema;

let Discipline = new Schema(
    {
        disciplineName: {
            type: String
        },
        single: {
            type: Boolean
        },
        minPlayers: {
            type: Number
        },
        maxPlayers: {
            type: Number
        },
        accepted: {
            type: Boolean
        }

    }
);

export default mongoose.model("Discipline", Discipline, "?");

*/



